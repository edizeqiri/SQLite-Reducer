CREATE  TABLE  biq (ype , ucn , ynu );
CREATE VIEW zua  AS  SELECT  ype, ucn,  AVG(ynu) FROM biq WHERE  ucn  BETWEEN 0  AND 1363441146  ;;
INSERT OR REPLACE INTO biq (ype, ucn, ynu) VALUES (CURRENT_TIMESTAMP , 1 , 1 );
SELECT  ucn, ype FROM biq WHERE biq.ype / 709620288 ;
